import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from 'src/app/config.service';
import { Product } from './product-add/product-add.component';

@Injectable()
export class ProductService {

    constructor(
        private httpClient: HttpClient,
        private configService: ConfigService) {

    }

    public List() {
        return this.httpClient.get(this.configService.APIURL + 'product');
    }

    public Get(productId: number) {
        return this.httpClient.get(this.configService.APIURL + 'product/' + productId);
    }

    public Add(product: Product) {
        return this.httpClient.post(this.configService.APIURL + 'product', product);
    }

    public Update(produictId: number, product: Product) {
        return this.httpClient.put(this.configService.APIURL + 'product/' + produictId, product);
    }

    public Delete(productId: number) {
        return this.httpClient.delete(this.configService.APIURL + 'product/' + productId);
    }
}
