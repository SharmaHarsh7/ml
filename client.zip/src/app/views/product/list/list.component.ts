import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, MatSnackBar } from '@angular/material';
import { ProductService } from '../product.service';
import { Product } from '../product-add/product-add.component';
import { ProductEditComponent } from '../product-edit/product-edit.component';
import { Router } from '@angular/router';

const ELEMENT_DATA: Product[] = [];

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
  providers: [ProductService]
})
export class ListComponent implements OnInit {

  displayedColumns: string[] = ['Name', 'Description', 'Quantity', 'Brand', 'Actions'];
  dataSource = new MatTableDataSource<Product>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  constructor(private productService: ProductService,
    private snackBar: MatSnackBar,
    private router: Router,
    public dialog: MatDialog) {

  }

  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    this.RefreshList();
  }

  private RefreshList() {
    this.productService.List().subscribe((res: any) => {
      this.dataSource = new MatTableDataSource<Product>(res);
    });
  }

  public OnEditClick(productId: number): void {
    this.router.navigateByUrl('product/edit/' + productId);
  }

  public OnDeleteClick(productId: number): void {
    this.productService.Delete(productId)
      .subscribe(res => {
        this.snackBar.open('Deleted successfully.', 'X');
        this.RefreshList();
      }, err => {
        this.snackBar.open('Something went wrong', 'X');
      });
  }
}
