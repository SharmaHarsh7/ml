import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { Product } from '../product-add/product-add.component';
import { ProductService } from '../product.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css'],
  providers: [ProductService]
})
export class ProductEditComponent implements OnInit {

  private productId: number;
  public productVM: Product = { ProductId: 0, Description: '', Brand: '', Name: '', Quantity: null };

  constructor(
    private router: Router,
    private activeRoute: ActivatedRoute,
    private productService: ProductService,
    private snackBar: MatSnackBar
  ) { }


  ngOnInit() {

    this.activeRoute.params.subscribe(params => {
      this.productId = +params['id'];
      this.productService.Get(this.productId)
        .subscribe((res: Product) => {
          this.productVM = res;
        }, err => {
          this.snackBar.open(err.error, 'X');
          this.router.navigateByUrl('product');
        });
    });
  }

  public OnSaveClick() {
    this.productService.Update(this.productId, this.productVM)
      .subscribe(res => {
        this.snackBar.open('Updated successfully', 'X');
        this.router.navigateByUrl('/product');
      }, err => {
        this.snackBar.open(err.error, 'X');
      });
  }
}
