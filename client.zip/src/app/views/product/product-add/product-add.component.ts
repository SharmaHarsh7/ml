import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';

export interface Product {
  ProductId: number;
  Name: string;
  Description: string;
  Quantity: number;
  Brand: string;
}

@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.css'],
  providers: [ProductService]
})
export class ProductAddComponent implements OnInit {
  public showSpinner = false;
  public productVM: Product = { ProductId: 0, Description: '', Brand: '', Name: '', Quantity: null };

  constructor(private router: Router,
    private snackBar: MatSnackBar,
    private productService: ProductService) { }

  ngOnInit() {
    // Temporary Key generation as we are not using RDBMS on server side
    this.productVM.ProductId = Math.floor(Math.random() * 9999) + 1;
  }

  public SaveProduct() {
    this.productService.Add(this.productVM)
      .subscribe(res => {
        this.snackBar.open('Product Saved, moving list', 'X');
        this.router.navigateByUrl('/product');
      }, err => {
        this.snackBar.open(err.error, 'X');
      });
  }

}
