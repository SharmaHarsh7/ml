import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginModule } from './login/login.module';
import { SharedModule } from './shared/shared.module';
import { FormsModule } from '@angular/forms';
import { AuthGuard } from './shared/auth-guard.service';
import { Routes, RouterModule } from '@angular/router';
import { FullLayoutComponent } from './full-layout/full-layout.component';
import { ConfigService } from './config.service';

const APP_CONTAINERS = [FullLayoutComponent];

const routes: Routes = [
  {
    path: '', component: FullLayoutComponent, canActivate: [AuthGuard], children: [
      {
        path: 'product', loadChildren: './views/product/product.module#ProductModule'
      }
    ]
  },
  { path: 'login', loadChildren: './login/login.module#LoginModule' }
];

@NgModule({
  declarations: [
    AppComponent,
    ...APP_CONTAINERS
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    LoginModule,
    SharedModule,
    RouterModule.forRoot(routes
      // , { useHash: true }
    )
  ],
  providers: [
    AuthGuard,
    ConfigService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
