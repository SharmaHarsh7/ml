import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {

  public userVM = { UserName: '', Password: '' };


  constructor(private router: Router,
    private snackBar: MatSnackBar) { }

  ngOnInit() {
  }

  public Login() {
    if (this.userVM.UserName === 'admin' && this.userVM.Password === '123') {
      localStorage.setItem('userInfo', JSON.stringify(this.userVM));
      this.router.navigateByUrl('/product');
    } else {
      this.snackBar.open('Invalid User Name or Password', 'X');
    }
  }
}
