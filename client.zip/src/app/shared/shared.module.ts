import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import {
  MatButtonModule, MatCheckboxModule, MatToolbarModule, MatInputModule,
  MatDialogModule, MatCardModule, MatMenuModule, MatIconModule, MatProgressSpinnerModule, MatTableModule, MatSnackBarModule,
  MatPaginatorModule,
  MatSortModule
} from '@angular/material';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [HeaderComponent, FooterComponent],
  imports: [
    HttpClientModule,
    CommonModule,
    MatButtonModule, MatCardModule, MatDialogModule, MatInputModule, MatTableModule,
    MatToolbarModule, MatMenuModule, MatIconModule, MatProgressSpinnerModule, MatPaginatorModule, MatCheckboxModule,
    MatDialogModule, MatSortModule
  ],
  exports:
    [
      HeaderComponent, FooterComponent,
      MatToolbarModule,
      MatButtonModule,
      MatCardModule,
      MatInputModule,
      MatDialogModule,
      MatTableModule,
      MatMenuModule,
      MatIconModule,
      MatSnackBarModule,
      MatProgressSpinnerModule,
      MatPaginatorModule,
      MatCheckboxModule,
      MatSortModule,
      MatDialogModule,
      HttpClientModule
    ]
})
export class SharedModule { }
