import { CanActivate, Router } from '@angular/router';
import { Injectable } from '@angular/core';

@Injectable()
export class AuthGuard implements CanActivate {
    constructor(private router: Router) { }

    canActivate() {
        const userInfo = localStorage.getItem('userInfo');

        if (userInfo) {
            return true;
        }

        console.error('Invalid user detected');

        this.router.navigate(['login']);
        return false;
    }
}
