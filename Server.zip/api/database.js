'use strict';
var alasql = require('alasql');

var db = new alasql.Database();

exports.Database = db;

exports.initDatabase = function (req, res) {
    db.exec("CREATE TABLE Product (ProductId INT PRIMARY KEY, Name STRING, Description STRING, Quantity INT, Brand STRING)");
    db.exec(" INSERT INTO Product VALUES " +
        "(1, 'Computer', 'Dell Computer', 10, 'Dell')," +
        "(2, 'Mouse', 'HP Mouse', 20, 'HP')," +
        "(4, 'Printer', 'Compaq Mouse', 20, 'Printer')," +
        "(5, 'Monitor', 'Sony Mouse', 20, 'Sony')," +
        "(6, 'CPU', 'AVS Mouse', 20, 'AVS')," +
        "(7, 'Cup', 'Coffee Cup', 20, 'CCD')," +
        "(8, 'Chair', 'Office Chair', 20, 'HomeFurnish')," +
        "(9, 'Mobile', 'Moto Mobile', 20, 'Motorola')," +
        "(10, 'Car', 'OOOOO', 20, 'Ford')," +
        "(3, 'Keybord', 'Lenovo Keyboard', 30, 'Lenovo'); ")

    db.exec("CREATE TABLE User (UserName STRING, PASSWORD STRING)");
    db.exec(" INSERT INTO User VALUES " +
        "('admin', 'admin'); ")
};
