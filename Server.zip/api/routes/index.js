'use strict';
var productRoutes = require('./product.route');
var userRoutes = require('./user.route');

module.exports = function (app) {

    app.route('/').get(function (req, res) {
        res.send('API Server is running');
    });

    productRoutes(app);
    userRoutes(app);
};
