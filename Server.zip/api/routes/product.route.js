'use strict';

module.exports = function (app) {
    var product = require('./../controllers/product.controller');

    app.route('/product/')
        .get(product.listAll)
        .post(product.insert);


    app.route('/product/:productId')
        .get(product.get)
        .put(product.update)
        .delete(product.delete);
};
