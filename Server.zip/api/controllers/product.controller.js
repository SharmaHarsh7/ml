'use strict';

var alasql = require('alasql');

var db = require('../database');

exports.listAll = function (req, res) {
    var data = db.Database.exec("select * from Product");

    res.json(data);
};

exports.get = function (req, res) {
    var data = db.Database.exec("select * from Product where ProductId = " + req.params.productId);

    if (data.length == 0) {
        res.status(404).send('Invalid Product Id');
    }

    res.json(data[0]);
};

exports.insert = function (req, res) {
    db.Database.exec(" INSERT INTO Product VALUES ("
        + req.body.ProductId + ", '"
        + req.body.Name + "', '"
        + req.body.Description + "', "
        + req.body.Quantity + ", '"
        + req.body.Brand + "')");

    res.json(req.body);
};

exports.update = function (req, res) {

    var data = db.Database.exec("select * from Product where ProductId = " + req.params.productId);

    if (data.length == 0) {
        res.status(404).send('Invalid Product Id');
    }


    db.Database.exec(" UPDATE Product SET ProductId = "
        + req.body.ProductId + ", Name = '"
        + req.body.Name + "', Description = '"
        + req.body.Description + "', Quantity = "
        + req.body.Quantity + ", Brand = '"
        + req.body.Brand + "' WHERE ProductId = " + req.params.productId);

    res.json(req.body);
};

exports.delete = function (req, res) {

    var data = db.Database.exec("select * from Product where ProductId = " + req.params.productId);

    if (data.length == 0) {
        res.status(404).send('Invalid Product Id');
    }

    db.Database.exec(" Delete FROM Product WHERE ProductId = " + req.params.productId);

    res.status(200).send();
};

