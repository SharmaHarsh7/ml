'use strict';

var alasql = require('alasql');

var db = require('../database');

exports.validate = function (req, res) {

    var data = db.Database.exec("select * from User where UserName = '" + req.body.UserName
        + "' AND Password = '" + req.body.Password + "'");

    if (data.length == 0) {
        res.status(401).send('Invalid UserName or Password');
    }

    res.json(data);
};

